setwd("C:/Users/Vector/Desktop/1-O")

library('twitteR')

setup_twitter_oauth("**", 
                    "**", 
                    "**",
                    "**")


search.string.cat <- c("#rajoy", "constitucion", "españa", "spain", "espanya", "catalonia", "catalunya", "gdemont")
search.string.es <- c("#1O", "referendum","catalonia", "rajoy", "cataluña", "españa", "constitucion", "gdemont")
search.string.eu <- c("#1O", "referendum","catalonia", "spain","democracy")

time <- Sys.time()
time <- gsub(':', '.', time)

##cat

tweets1 <- searchTwitter(search.string.cat[1], n=500, geocode="41.83,1.548593,111km", resultType="recent")
tweets2 <- searchTwitter(search.string.cat[2], n=500, geocode="41.83,1.548593,111km", resultType="recent")
tweets3 <- searchTwitter(search.string.cat[3], n=500, geocode="41.83,1.548593,111km", resultType="recent")
tweets4 <- searchTwitter(search.string.cat[4], n=500, geocode="41.83,1.548593,111km", resultType="recent")
tweets5 <- searchTwitter(search.string.cat[5], n=500, geocode="41.83,1.548593,111km", resultType="recent")
tweets6 <- searchTwitter(search.string.cat[6], n=500, geocode="41.83,1.548593,111km", resultType="recent")
tweets7 <- searchTwitter(search.string.cat[7], n=500, geocode="41.83,1.548593,111km", resultType="recent")
tweets8 <- searchTwitter(search.string.cat[8], n=500, geocode="41.83,1.548593,111km", resultType="recent")


d1 = twListToDF(tweets1)
d2 = twListToDF(tweets2)
d3 = twListToDF(tweets3)
d4 = twListToDF(tweets4)
d5 = twListToDF(tweets5)
d6 = twListToDF(tweets6)
d7 = twListToDF(tweets7)
d8 = twListToDF(tweets8)


d <- rbind(d1,d2,d3,d4,d5,d6,d7,d8)

################################################### WITHOUT RETWEET
d1r<-d1[-grep("RT", d1$text),]
d2r<-d2[-grep("RT", d2$text),]
d3r<-d3[-grep("RT", d3$text),]
d4r<-d4[-grep("RT", d4$text),]
d5r<-d5[-grep("RT", d5$text),]
d6r<-d6[-grep("RT", d6$text),]
d7r<-d7[-grep("RT", d7$text),]
d8r<-d8[-grep("RT", d8$text),]

dr <- rbind(d1r,d2r,d3r,d4r,d5r,d6r,d7r,d8r)

write.csv2(d, paste("./csv/catAll ", time, ".csv", sep=""))
write.csv2(dr, paste("./csv/catNRT ", time, ".csv", sep=""))




###SHOW 6 MOST RETWEETED FROM EACH DF
#head(d[order(d$retweetCount, decreasing = T), c(1,12)])
#head(dr[order(dr$retweetCount, decreasing = T), c(1,12)])


########## es


tweets1 <- searchTwitter(search.string.es[1], n=200, geocode="40.38,-3.62,290km", resultType="recent")
tweets2 <- searchTwitter(search.string.es[2], n=200, geocode="40.38,-3.62,290km", resultType="recent")
tweets3 <- searchTwitter(search.string.es[3], n=200, geocode="40.38,-3.62,290km", resultType="recent")
tweets4 <- searchTwitter(search.string.es[4], n=200, geocode="40.38,-3.62,290km", resultType="recent")
tweets5 <- searchTwitter(search.string.es[5], n=200, geocode="40.38,-3.62,290km", resultType="recent")


d1 = twListToDF(tweets1)
d2 = twListToDF(tweets2)
d3 = twListToDF(tweets3)
d4 = twListToDF(tweets4)
d5 = twListToDF(tweets5)
d6 = twListToDF(tweets6)
d7 = twListToDF(tweets7)
d8 = twListToDF(tweets8)


d <- rbind(d1,d2,d3,d4,d5,d6,d7,d8)

################################################### WITHOUT RETWEET
d1r<-d1[-grep("RT", d1$text),]
d2r<-d2[-grep("RT", d2$text),]
d3r<-d3[-grep("RT", d3$text),]
d4r<-d4[-grep("RT", d4$text),]
d5r<-d5[-grep("RT", d5$text),]
d6r<-d6[-grep("RT", d6$text),]
d7r<-d7[-grep("RT", d7$text),]
d8r<-d8[-grep("RT", d8$text),]

dr <- rbind(d1r,d2r,d3r,d4r,d5r,d6r,d7r,d8r)

write.csv2(d, paste("./csv/esAll ", time, ".csv", sep=""))
write.csv2(dr, paste("./csv/esNRT ", time, ".csv", sep=""))





########## eu


tweets1 <- searchTwitter(search.string.eu[1], n=200, lang="en", geocode="50.17,14.75,1190km", resultType="recent")
tweets2 <- searchTwitter(search.string.eu[2], n=200, lang="en", geocode="50.17,14.75,1190km", resultType="recent")
tweets3 <- searchTwitter(search.string.eu[3], n=200, lang="en", geocode="50.17,14.75,1190km", resultType="recent")
tweets4 <- searchTwitter(search.string.eu[4], n=200, lang="en", geocode="50.17,14.75,1190km", resultType="recent")
tweets5 <- searchTwitter(search.string.eu[5], n=200, lang="en", geocode="50.17,14.75,1190km", resultType="recent")



d1 = twListToDF(tweets1)
d2 = twListToDF(tweets2)
d3 = twListToDF(tweets3)
d4 = twListToDF(tweets4)
d5 = twListToDF(tweets5)
d6 = twListToDF(tweets6)
d7 = twListToDF(tweets7)
d8 = twListToDF(tweets8)


d <- rbind(d1,d2,d3,d4,d5,d6,d7,d8)

################################################### WITHOUT RETWEET
d1r<-d1[-grep("RT", d1$text),]
d2r<-d2[-grep("RT", d2$text),]
d3r<-d3[-grep("RT", d3$text),]
d4r<-d4[-grep("RT", d4$text),]
d5r<-d5[-grep("RT", d5$text),]
d6r<-d6[-grep("RT", d6$text),]
d7r<-d7[-grep("RT", d7$text),]
d8r<-d8[-grep("RT", d8$text),]

dr <- rbind(d1r,d2r,d3r,d4r,d5r,d6r,d7r,d8r)

write.csv2(d, paste("./csv/euAll ", time, ".csv", sep=""))
write.csv2(dr, paste("./csv/euNRT ", time, ".csv", sep=""))
